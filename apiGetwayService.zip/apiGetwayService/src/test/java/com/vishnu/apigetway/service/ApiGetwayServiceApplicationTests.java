package com.vishnu.apigetway.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGetwayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
