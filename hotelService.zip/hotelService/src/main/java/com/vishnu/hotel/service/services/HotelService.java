package com.vishnu.hotel.service.services;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import com.vishnu.hotel.service.entities.Hotels;


public interface HotelService {
   Hotels saveHotel(Hotels hotels);
   Hotels getHotel(String hotelId);
   List<Hotels> getAllHotels();
ResponseEntity<Hotels> updateHotel(WebRequest request, String hotelId,Hotels hotel);
}
