package com.vishnu.hotel.service.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishnu.hotel.service.entities.Hotels;

public interface HoltelRepository extends JpaRepository<Hotels, String>{

}
