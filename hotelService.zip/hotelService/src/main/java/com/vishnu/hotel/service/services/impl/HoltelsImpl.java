package com.vishnu.hotel.service.services.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.WebRequest;

import com.vishnu.hotel.service.entities.Hotels;
import com.vishnu.hotel.service.exception.ResourceNotFoundException;
import com.vishnu.hotel.service.repositories.HoltelRepository;
import com.vishnu.hotel.service.services.HotelService;

@Service
public class HoltelsImpl implements HotelService {
	@Autowired
	HoltelRepository hotelRepository;

	@Override
	public Hotels saveHotel(Hotels hotels) {
		// TODO Auto-generated method stub
		String id=UUID.randomUUID().toString();
		hotels.setId(id);
		return hotelRepository.save(hotels);
	}

	@Override
	public Hotels getHotel(String hotelId) {
		// TODO Auto-generated method stub
		return hotelRepository.findById(hotelId).orElseThrow(()-> new ResourceNotFoundException("Hotel not found"));
	}

	@Override
	public List<Hotels> getAllHotels() {
		// TODO Auto-generated method stub
		return hotelRepository.findAll();
	}

	@Override
	public ResponseEntity<Hotels> updateHotel(WebRequest request, String hotelId,Hotels hotelRequest) {
		// TODO Auto-generated method stub
		Hotels hotel = hotelRepository.findById(hotelId).get();
	    if (hotel == null) {
	        return ResponseEntity.notFound().build();
	    }
	    String ifMatchValue = request.getHeader("If-Match");
	    if (ifMatchValue.isEmpty()) {
	        return ResponseEntity.badRequest().build();
	    }
	    if (!ifMatchValue.equals("\"" + hotel.getVersion() + "\"")) {
	        return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).build();
	    }
	    try {
	    	return ResponseEntity.ok().eTag("\"" + hotel.getVersion() + "\"").body(hotelRepository.saveAndFlush(hotelRequest));
	    	} catch (OptimisticLockingFailureException ex){
	    	     return ResponseEntity.status(HttpStatus.CONFLICT).build();
	    	   } 
	    }

}
