package com.vishnu.rating.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vishnu.rating.service.entities.Rating;

public interface RatingRepository extends JpaRepository<Rating, String> {
	@Query("SELECT u FROM Rating u WHERE u.userId = :userId")
	List<Rating> finByUserId(String userId);
	@Query("SELECT u FROM Rating u WHERE u.hotelId = :hotelId")
	List<Rating> finByHotelId(String hotelId);

}
