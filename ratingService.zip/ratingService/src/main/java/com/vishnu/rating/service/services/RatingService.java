package com.vishnu.rating.service.services;

import java.util.List;

import com.vishnu.rating.service.entities.Rating;

public interface RatingService {

	List<Rating> getByUserId(String userId);

	List<Rating> getByHotelId(String hotelId);

	List<Rating> getAllRating();

	Rating createRating(Rating rating);

}
