package test;

public class Employee {
    private int sal;
    public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	private String grade;
    
    public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name;
	public Employee(String name, int sal) {
		this.name=name;
		this.sal=sal;
	}
	public Employee(String name, int sal,String grade) {
		this.name=name;
		this.sal=sal;
		this.grade=grade;
	}
	@Override
	public String toString() {
		return "Employee [sal=" + sal + ", name=" + name + "]";
	}

}
