package test;

public class LinkedList  {
	Node head;
	static class Node { 
	    
        int data; 
        Node next; 
    
        // Constructor 
        Node(int d) 
        { 
            data = d; 
            next = null; 
        } 
        public static LinkedList  insert(LinkedList list, int data) {
        	Node new_node=new Node(data);
        	if(list.head==null) {
        		list.head=new_node;
        	}else {
        		Node last=list.head;
        		while(last.next!=null) {
        			last=last.next;
        		}
        		last.next=new_node;
        	}
			return list;
        }
       public static void print(LinkedList list) {
    		   Node node=list.head;
    			   while(node!=null) {
    				   System.out.println(node.data);
    				   node=node.next;
    			   }
       }
       private static LinkedList add(LinkedList list, LinkedList list2) {
    	   int carry=0;
    	   int sum=0;
    	   LinkedList list3 = new LinkedList(); 
    	   Node node=list.head;
    	   Node node2=list2.head;
    	   while(node!=null) {
    		  
        	    
        	   int firstData=node!=null && node.data!=0?node.data:0;
        	   int secondData=node2!=null && node2.data!=0?node2.data:0;
        	   sum=firstData+secondData+carry;
        	   carry=sum/10;
        	
        	   //System.out.println(firstData+" "+secondData);
        	   node=node!=null?node.next:new Node(0);
        	   node2=node2!=null?node2.next:new Node(0);
        	   if(node!=null) {
        		   sum=sum%10;
        	   }
        	  
        	   insert(list3, sum);
        	   
    	   }
    	   
   		return list3;
   	}
    public static void main(String[] str) {
        LinkedList list = new LinkedList(); 
        LinkedList list2 = new LinkedList(); 
        list = insert(list, 9); 
        list = insert(list, 9); 
        list = insert(list, 9); 
        list = insert(list, 9);
        list = insert(list, 9);
        list = insert(list, 9);
        list = insert(list, 9);
        
        
        list2 = insert(list2, 9); 
        list2 = insert(list2, 9); 
        list2 = insert(list2, 9);
        list2 = insert(list2, 9);
         
        
        
        //print(list);
        //print(list2);
        
        LinkedList list3= add(list,list2);
        print(list3);
    }
	
}
}
