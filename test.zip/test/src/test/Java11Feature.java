package test;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Java11Feature {
	public static void main(String[] arg) {
		String data="Baeldung helps \n \n developers \n explore Java.";
		 List<String> dataList=data.lines().filter(list->!list.isBlank()).map(e->e).collect(Collectors.toList());
         System.out.println(dataList);		 
	}
 
}
