package test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class JAVA8Feature {

	public static void main(String[] args) {
		//findEvenNumbersFromList();
		//findTheNumberStartedWithOne();
		  //findDublicateInIntegerList();
		//findTheFirstElementOfList();
		//findTotalNumberOfElementInList();
		  //findMaxValueInList();
		  //convertStringToCharacterLowerLetter();
		//storeTheChacraterWithCount();
		//findFistSingleRepeatedCharacterInString();
		//findFirstRepeatedCharacterInString();
		//sortListOfInteger();
		//reduceMethodExample();
		//consumerExample();
		//supplierExample();
		//optionalExample();
		//flatMapExample();
		//DateAPIExample();
		//biFunction();
		//biConsumer();
		//biPredicate();
		
		
		
		
		//twoSum();
		//checkPalondrom();
		//romanToInteger();
		//longestSubstringWithoutRepeatingCharacters();
		
		
		
		//reverseAString();
		//removeDuplicateFromList();
		//hashMapVsLinkedHashMap();
		parallerAndSequecialStream();
		
		
	}

	private static void parallerAndSequecialStream() {
		IntStream range = IntStream.rangeClosed(1, 10);
		System.out.println("Starting Time"+LocalTime.now());
		range.asLongStream().forEach(System.out::println);;
		System.out.println("End Time"+LocalTime.now());
		System.out.println("Starting Time"+LocalTime.now());
		IntStream range2 = IntStream.rangeClosed(1, 10);
		range2.parallel().forEach(System.out::println);
		System.out.println("Starting Time"+LocalTime.now());
		
	}

	private static void hashMapVsLinkedHashMap() {
		Map<String,String> map=new HashMap<>();
		Map<String,String> map1=new LinkedHashMap<>();
		map.put("vishnu", "vishnu");
		map.put("pintu", "pintu");
		map.put("Rakesh", "Rakesh");
		map.put("arvind", "arvind");
		
		map1.put("vishnu", "vishnu");
		map1.put("pintu", "pintu");
		map1.put("Rakesh", "Rakesh");
		map1.put("arvind", "arvind");
		
		Map<String, Integer> budget = new HashMap<>(); 
		budget.put("clothes", 120); 
		budget.put("grocery", 150); 
		budget.put("transportation", 100); 
		budget.put("utility", 130); 
		budget.put("rent", 1150); 
		budget.put("miscellneous", 90);

		
		
		
		map
        .entrySet()
        .stream()
        .sorted(Map.Entry.comparingByKey())
        .collect(
            Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,
                LinkedHashMap::new)).entrySet().forEach(System.out::println);;
	
	
		
	}

	private static void removeDuplicateFromList() {
		List<String> st=Arrays.asList("vishnu","pintu","vishnu","pintu","rakesh");
		List<Employee> st1=Arrays.asList(
				new Employee("vishnu", 10,"A"),
				new Employee("pintu", 20, "B"),
				new Employee("pintu", 20,"A")
				);
		//st.stream().distinct().forEach(System.out::println);
		//st.stream().collect(Collectors.toSet()).forEach(System.out::println);
		
		//reverse the list
//			    st.stream().collect(ArrayList::new,
//			                  (list, e) -> list.add(0, e),
//			                  (list1, list2) -> list1.addAll(0, list2)).forEach(System.out::println);
//			    st1.stream().collect(ArrayList::new,(list,e)->list.add(0,e),(list1,list2)->list1.addAll(0,list2))
//			                .forEach(System.out::println);
			    st1.stream().collect(Collectors.groupingBy(Employee::getName))
			    .entrySet().forEach(System.out::println);
	}

	private static void reverseAString() {
		String data="vishnu is good boy";
		String st=new StringBuilder(data).reverse().toString();
		
		String reversed=data.chars().mapToObj(e->(char)e).reduce("",(s,e)->e+s,(s1,s2)->s2+s1);
		String reversed2=data.chars()
				.collect(StringBuilder::new,(b,c)->b.insert(0,(char)c),(b1,b2)->b1.insert(0,b2))
				.toString();
		
		String reversed3=Stream.of(data)
                .map(word->new StringBuilder(word).reverse())
                .collect(Collectors.joining(" "));
		String reversed4=IntStream.range(0, data.length())
				.map(i->data.charAt(data.length()-i-1))
				.collect(StringBuilder::new, (sb,c)->sb.append((char)c), StringBuilder::append)
				.toString();
		System.out.println(reversed4);
	}

	private static void biPredicate() {
		BiPredicate<String, String> bipredicate=(val1,val2)->val1.equals(val2);
		BiPredicate<String, String> bipredicate2=(val1,val2)->val1.length()==val2.length();
		System.out.println(bipredicate.test("vishnu", "vishnu"));
		System.out.println(bipredicate.or(bipredicate2).test("vishnu", "vishnu"));
		
	}

	private static void biConsumer() {
		BiConsumer<String, Integer> biConsumer=(val1,val2)->{
			System.out.println(val1+" "+val2);
		};
		
		biConsumer.accept("rakesh", 12);
		
		Map<String, Integer> map=new HashMap<>();
		map.put("rakesh", 1);
		map.put("pintu", 2);
		map.put("harish", 3);
		map.forEach(biConsumer);
	}

	private static void biFunction() {
		Map<String,Integer> map=new HashMap<>();
		map.put("vikash", 120);
		map.put("harish", 1300);
		map.put("karis", 10);
		map.replaceAll((key,value)->value*2);
		System.out.println(map.toString());
		
		//sort map
		map.entrySet().stream().sorted((a,b)->a.getValue().compareTo(b.getValue()))
		.forEach(System.out::println);
		
		List<Integer> list1=Arrays.asList(12,14,18,25,20);
		List<Integer> list2=Arrays.asList(1,4,8,2,5);
		//sum of list
		int sum=list2.stream().mapToInt(e->e).sum();
		System.out.println("sume is "+ sum);
		//declare bifunction body
		BiFunction<List<Integer>, List<Integer>, List<Integer>> bifunction=(l1,l2)->{
			return Stream.of(l1,l2).flatMap(List::stream).distinct().collect(Collectors.toList());
		};
		
		//declare function for sorting
		Function<List<Integer>, List<Integer>> functionsort=(list)->list.stream().sorted().collect(Collectors.toList());
		
		// call this function
		System.out.println(bifunction.andThen(functionsort).apply(list1, list2));
		
	}

	private static void DateAPIExample() {
		LocalDate dab=LocalDate.of(1993, Month.AUGUST,10 );
		LocalDate today=LocalDate.now();
		if(dab.isBefore(today)) {
			System.out.println("befour the time");
		}
		Period period=Period.between(dab, today);
		int year=period.getYears();
		int month=period.getMonths();
		int day=period.getDays();
		System.out.println(day+" "+month+" "+year);
		
		//next wednes day
		LocalDate nextWednusday=today.with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY));
		System.out.println(nextWednusday);
		
	}

	private static void flatMapExample() {
		Map<String,List<String>> data=new HashMap<>();
		data.put("vikas", Arrays.asList("1212321","345345"));
		data.put("pintu", Arrays.asList("54334","67674"));
		//provide list of string
		data.values().stream().flatMap(Collection::stream).collect(Collectors.toList())
		.forEach(e->System.out.println(e));
		//provide list of Stream<string>
		data.values().stream().map(Collection::stream).collect(Collectors.toList())
		                      .forEach(e->e.toList().forEach(e1->System.out.println(e1)));
		
		data.entrySet().stream().forEach(e->System.out.println(e.getKey()));
		
		Map<String, Map<String, ArrayList<Employee>>> map = new HashMap<String, Map<String, ArrayList<Employee>>>();
		ArrayList<Employee> list = new ArrayList<Employee>();
		Map<Integer, List<Employee>> empMap = new HashMap<>();

		Employee e1 = new Employee("Raju", 10000);
		Employee e2 = new Employee("Naresh", 10000);
		Employee e3 = new Employee("Sugg", 30000);
		Employee e4 = new Employee("Asd", 30000);
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		empMap= list.stream().collect(Collectors.groupingBy(Employee::getSal,Collectors.toList()));
		System.out.println(empMap.toString());
		
		
		list.stream().sorted(Comparator.comparing(Employee::getName).thenComparing(Employee::getSal))
		.forEach(System.out::println);
		//System.out.println(map.toString());
		
	}

	private static void optionalExample() {
		List<String> cities = Arrays.asList("Sydney", "Dhaka", "New York", "London");
		Optional<String> option=cities.stream().findFirst();
		System.out.println(option.get());
		
	}

	private static void supplierExample() {
		Supplier<Double> supp=()->Math.random();
		DoubleSupplier  doubleSupp=Math::random;
		System.out.println(supp.get());
		System.out.println(doubleSupp.getAsDouble());
		
		Supplier<Double> doubleSupplier = () -> Math.random();
	    Optional<Double> optionalDouble = Optional.empty();
	    System.out.println(optionalDouble.orElseGet(doubleSupplier));
		
		//IntSupplier int getAsInt();
		//DoubleSupplier double getAsDouble();
		//LongSupplier long getAsLong();
		//BooleanSupplier boolean getAsBoolean();
	}

	private static void consumerExample() {
        Consumer<String> consumer=t->System.out.println(t);
        Stream<String> stream=Stream.of("vishnu","pintu");
        stream.forEach(consumer);
        
        
        List<String> cities = Arrays.asList("Sydney", "Dhaka", "New York", "London");

        Consumer<List<String>> upperCaseConsumer = list -> {
            for(int i=0; i< list.size(); i++){
                list.set(i, list.get(i).toUpperCase());
            }
        };
        Consumer<List<String>> printConsumer = list -> list.stream().forEach(System.out::println);

        upperCaseConsumer.andThen(printConsumer).accept(cities);
        
        //IntConsumer void accept(int x);
        //DoubleConsumer void accept(double x);
        //LongConsumer void accept(long x);
	}

	private static void reduceMethodExample() {
		//int sum=
		Stream
				   .iterate(4, multipleOfFour -> multipleOfFour+4)
				   .limit(10)
				   .map(multipleOfFour -> multipleOfFour*multipleOfFour)
				   .filter(multipleOfFourSquared->multipleOfFourSquared%10==0)
				   //.reduce(0, Integer::sum);
				   .forEach(e->System.out.println(e));
		
//System.out.println(sum);
		
		List<Employee> emp=new ArrayList<>();
		emp.add(new Employee("rakes", 10,"A"));
		emp.add(new Employee("Harish", 11,"B"));
		emp.add(new Employee("Mohan", 18,"B"));
		emp.add(new Employee("sohan", 16,"C"));
		
		emp.stream().collect(Collectors.groupingBy(Employee::getGrade,Collectors.averagingInt(Employee::getSal)))
		.entrySet()
		.forEach(e->System.out.println(e.getKey()+" "+e.getValue()));
		
		int sum=emp.stream().map(e->e.getSal()).reduce(Integer::sum).get();
		System.out.println(sum);
		
		OptionalDouble avg=emp.stream().map(e->e.getSal()).mapToDouble(i->i).average();
		System.out.println(avg.getAsDouble());
		
		
	}

	private static void longestSubstringWithoutRepeatingCharacters() {
		
		
	}

	private static void romanToInteger() {
		Map<Character,Integer> map=new HashMap<>();
		map.put('I', 1);
		map.put('V', 5);
		map.put('X', 10);
		map.put('L', 50);
		map.put('C', 100);
		map.put('M', 1000);
		int total=0;
		char[] roman= {'X','I'};
		for(int i=roman.length-1;i!=-1;i--) {
			if(i==roman.length-1) {
				total+=map.get(roman[i]);
				//System.out.println(total);
			}
			if(i<roman.length-1) {
				if(map.get(roman[i])<map.get(roman[i+1])) {
					total=total-map.get(roman[i]);
					//System.out.println(total);
				}else {
					total=total+map.get(roman[i]);
					//System.out.println(total);
				}
			}
			
		}
		System.out.println(total);
	}

	private static void checkPalondrom() {
		int[] array= {1,3,3,1};
		boolean flag=true;
		for(int i=0;i<array.length/2;i++) {
			if(array[i]!=array[(array.length-1)-i]) {
				flag=false;
			}
		}
		if(flag) {
			System.out.println("polydrom");
		}else {
			System.out.println("not polydrom");
		}
		
	}

	private static void twoSum() {
		// TODO Auto-generated method stub
		int target=5;
		int[] nums= {3,2,4}; 
		 Map<Integer,Integer> map=new HashMap<>();
	      for(int i=0;i<nums.length;i++) {
	    	  int com=target-nums[i];
	    	  if(map.containsKey(com)) {
	    		  System.out.println(map.get(com)+" "+i);
	    	  } 
	    	  map.put(nums[i], i);
	      }
	       
	}

	private static void sortListOfInteger() {
		 List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
		 myList.stream().sorted().forEach(System.out::println);
		 myList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
	}

	private static void findFirstRepeatedCharacterInString() {
		String input = "Java Hungry Blog Alive is Awesome";
		input.chars().mapToObj(e->Character.toLowerCase((char)e))
		             .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		             .entrySet()
		             .stream()
		             .filter(e->e.getValue()>1L)
		             .findFirst()
		             .ifPresent(System.out::println);
		
	}

	private static void findFistSingleRepeatedCharacterInString() {
		String input = "Java Hungry Blog Alive is Awesome";
		input.chars().mapToObj(e->Character.toLowerCase((char)e))
				          .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
				          .entrySet()
				          .stream()
				          .filter(e->e.getValue()==1L)
				          .map(e->e.getKey())
				          .findFirst()
				          .ifPresent(System.out::println);
		
		
	}

	private static void storeTheChacraterWithCount() {
		String input = "Java Hungry Blog Alive is Awesome";
		input.chars().mapToObj(e->Character
				.toLowerCase(Character.valueOf((char)e)))
		 .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		 .entrySet()
		 .stream().forEach(e->System.out.println(e.toString()));
		
	}

	private static void convertStringToCharacterLowerLetter() {
		String input = "Java Hungry Blog Alive is Awesome";
		input.chars().mapToObj(e->Character
				.toLowerCase(Character.valueOf((char)e)))
		        .forEach(e->System.out.println(e));
	}

	private static void findMaxValueInList() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(12);
		list.add(3);
		list.add(2);
		list.add(2);
		
		int max=list.stream()
		.max(Integer::compare).get();
		
		System.out.println(max);
		
	}

	private static void findTotalNumberOfElementInList() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(8);
		list.add(3);
		list.add(2);
		list.add(2);
		
		Long count=list.stream()
		.count();
		
		System.out.println(count);
		
	}

	private static void findTheFirstElementOfList() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(8);
		list.add(3);
		list.add(2);
		list.add(2);
		
		list.stream()
		.findFirst()
		.ifPresent(System.out::println);
		
	}

	private static void findDublicateInIntegerList() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(8);
		list.add(3);
		list.add(2);
		list.add(2);
		Set<Integer> set=new HashSet<>();
		list.stream().filter(e->!set.add(e)).forEach(e->System.out.println(e));
		
	}

	private static void findTheNumberStartedWithOne() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(8);
		list.add(3);
		list.add(2);
		list.stream().map(e->e+"")
				.filter(e->e.startsWith("1"))
				.forEach(e->System.out.println(e));
		
		
	}

	private static void findEvenNumbersFromList() {
		List<Integer> list=new ArrayList<>();
		list.add(9);
		list.add(1);
		list.add(8);
		list.add(3);
		list.add(2);
		list.stream().filter(e-> e%2==0)
				.forEach(e->System.out.println(e));
		
		
	}

}
