package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ImutableClass implements Cloneable{
    private final String firstName;
    private final String lastName;
    private final  List<String> accounts;

    public ImutableClass(String firstName, String lastName, List<String> accounts) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.accounts = accounts;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public List<String> getAccounts() {
      // return Collections.unmodifiableList(accounts);
        return List.of(accounts.toArray(new String[]{}));
    }

    public static void main(String[] args) {
        List<String> accounts = new ArrayList<>();
        accounts.add("A");
        accounts.add("B");
        accounts.add("C");
        ImutableClass customer = new ImutableClass("Rohit","Asthana",accounts);
        customer.accounts.add("D");
        //List<String> list=customer.getAccounts();
        //list.add("E");
        //list.stream().forEach(System.out::println);
       
    }
}

