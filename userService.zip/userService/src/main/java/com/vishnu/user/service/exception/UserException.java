package com.vishnu.user.service.exception;

public class UserException extends RuntimeException {
	
	public UserException(){
		super("User not fund");
		
	}
	public UserException(String message){
		super(message);
		
	}

}
