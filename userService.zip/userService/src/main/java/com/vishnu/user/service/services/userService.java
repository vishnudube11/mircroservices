package com.vishnu.user.service.services;

import java.util.List;

import com.vishnu.user.service.entities.User;

public interface userService {
 User saveUser(User user);
 List<User> getAllUsers();
 User getUser(String userId);
 
}
