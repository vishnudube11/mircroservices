package com.vishnu.user.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishnu.user.service.entities.User;
import com.vishnu.user.service.services.userService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	userService userService;
	int retry=1;
	@PostMapping
	public ResponseEntity<User> saveUser(@RequestBody User user){
		return ResponseEntity.status(HttpStatus.CREATED).body(userService.saveUser(user));
	}
	@GetMapping("/{userId}")
	//@CircuitBreaker(name= "ratingHotelBreaker",fallbackMethod = "ratingHotelFallback")
	//@Retry(name="retryRatingHotel",fallbackMethod="ratingHotelFallback")
	@RateLimiter(name="userRateLimiter",fallbackMethod="ratingHotelFallback")
	public ResponseEntity<User> getUser(@PathVariable String userId){
//		System.out.println("Retry "+retry);
//		retry++;
		return ResponseEntity.status(HttpStatus.OK).body(userService.getUser(userId));
	}
 
	public ResponseEntity<User> ratingHotelFallback(String userId,Exception ex) {
		System.out.println("rating Hotel FallBack issue");
		User user=User.builder().name("Dummy").email("Dummy@mail.com").build();
		return ResponseEntity.ok(user);
		
	}
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers(){
		return ResponseEntity.ok(userService.getAllUsers());
	}
}
