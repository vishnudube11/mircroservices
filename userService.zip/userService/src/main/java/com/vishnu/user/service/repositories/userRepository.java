package com.vishnu.user.service.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishnu.user.service.entities.User;

public interface userRepository extends JpaRepository<User,String > {

}
