package com.vishnu.user.service.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vishnu.user.service.entities.Hotel;
import com.vishnu.user.service.entities.Rating;
import com.vishnu.user.service.entities.User;
import com.vishnu.user.service.exception.UserException;
import com.vishnu.user.service.external.services.HotelService;
import com.vishnu.user.service.repositories.userRepository;
import com.vishnu.user.service.services.userService;

@Service
public class userServiceImpl implements userService  {
	
	@Autowired
	private userRepository userRepository;
	
	@Autowired RestTemplate restTemplate;
	
	@Autowired
	HotelService hotelService;

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		user.setUserId(UUID.randomUUID().toString());
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUser(String userId) {
		// TODO Auto-generated method stub
		User user=userRepository.findById(userId).orElseThrow(()->new UserException("User Id Not Found "+userId));
		Rating[] rating=restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+userId, Rating[].class);
		List<Rating> finalRating=Arrays.stream(rating).toList();
		List<Rating> ratingList=finalRating.stream().map(r->{
			//Hotel hotel=restTemplate.getForObject("http://HOTEL-SERVICE/hotel/"+r.getHotelId(), Hotel.class);
			Hotel hotel=hotelService.getHotel(r.getHotelId());
			r.setHotel(hotel);
			return r;
		}).toList();
		user.setRating(ratingList);
		return user;
	}

}
