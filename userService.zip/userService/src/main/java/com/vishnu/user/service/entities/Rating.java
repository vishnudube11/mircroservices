package com.vishnu.user.service.entities;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Rating {
private String ratingId;
private String userId;
private String hotelId;
private String remarks;
private int rating;
private Hotel hotel;
}
